#!/usr/bin/env zsh

echo "No automatic verification possible"